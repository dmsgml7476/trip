function submitProfile() {
	const form = document.getElementById('profileForm');
	form.submit();
}