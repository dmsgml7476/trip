package com.trip.control.Lets;

public class StroryController {

}
