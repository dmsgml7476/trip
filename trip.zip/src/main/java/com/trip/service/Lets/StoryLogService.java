package com.trip.service.Lets;

public class StoryLogService {

}
