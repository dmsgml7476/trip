package com.trip.dto.Lets;

public class StoryResponseDto {

}
