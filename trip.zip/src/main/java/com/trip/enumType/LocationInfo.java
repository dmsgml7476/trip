package com.trip.enumType;

public enum LocationInfo {
				ALLOWED,  //위치정보 허용
				DENINED // 위치 정보 거부
}
