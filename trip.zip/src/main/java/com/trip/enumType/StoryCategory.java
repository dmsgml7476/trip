package com.trip.enumType;

public enum StoryCategory {
	CATEGORY,   // 카테고리별
    LATEST,     // 최신순
    REGION,     // 지역별
    SEASON      // 시즌별
}
