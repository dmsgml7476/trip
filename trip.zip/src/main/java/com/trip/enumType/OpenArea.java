package com.trip.enumType;

public enum OpenArea {
			PUBLIC,
			FRIEND_ONLY,
			PRIVATE
}
