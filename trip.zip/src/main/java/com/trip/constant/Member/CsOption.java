package com.trip.constant.Member;

public enum CsOption {
	COMPLAIN, ETC
}
