package com.trip.constant.Member;

public enum Status {
	WAITING, IN_PROGRESS, ANSWERED
}
