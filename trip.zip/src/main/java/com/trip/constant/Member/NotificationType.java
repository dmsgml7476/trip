package com.trip.constant.Member;

public enum NotificationType {
	TRIP_START, STORY, CUSTOMER_REPLY, PLAN_APPLICATION, PLAN_RESPONSE
}
