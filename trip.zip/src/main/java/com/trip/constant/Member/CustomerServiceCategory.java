package com.trip.constant.Member;

public enum CustomerServiceCategory {
	TRAVEL, TOGETHER, STORY, ETC
}
