package com.trip.constant.Member;

public enum MainStoryNum {
ONE, TWO, THREE, FORE, FIVE
}
