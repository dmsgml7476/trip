package com.trip.constant.Member;

public enum Role {
	USER, ADMIN, WITHDRAW

}
